from django.apps import AppConfig


class SdnsConfig(AppConfig):
    name = 'sdns'
