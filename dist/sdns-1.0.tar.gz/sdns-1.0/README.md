Plugin para o sdns
